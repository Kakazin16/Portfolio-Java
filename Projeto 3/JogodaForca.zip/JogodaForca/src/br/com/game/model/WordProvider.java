package br.com.game.model;

import java.util.List;
import java.util.Random;

public class WordProvider {

    private static final List<String> WORDS = List.of(
            "JAVA", "CLASSE", "OBJETO", "HERANCA",
            "POLIMORFISMO", "METODO", "ATRIBUTO"
    );

    public static String getRandomWord() {
        Random r = new Random();
        return WORDS.get(r.nextInt(WORDS.size()));
    }
}
