package br.com.game.model;

public abstract class Game {
	
	private String name;
	
	
	
	public Game (String name) {
		
		this.name = name;
	}
	
	public String getName() {
		
		return name;
	}
	
    public abstract void start();


    public void showIntro() {
        System.out.println("Iniciando o jogo: " + name);
    }
	
}
