package br.com.game.model;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class HangmanGame extends Game {
    private final String word;
    private final Set<Character> usedLetters = new HashSet<>();
    private int attempts = 6;

    public HangmanGame() {
        super("Jogo da Forca");
        this.word = WordProvider.getRandomWord().toUpperCase();
    }

    @Override
    public void start() {
        showIntro();
        @SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);

        while (attempts > 0) {
            System.out.println("\nPalavra: " + getMaskedWord());
            System.out.println("Tentativas restantes: " + attempts);
            System.out.println("Letras usadas: " + usedLetters);
            System.out.print("Digite uma letra: ");

            char guess = sc.nextLine().toUpperCase().charAt(0);

            if (usedLetters.contains(guess)) {
                System.out.println("Você já tentou essa letra!");
                continue;
            }

            usedLetters.add(guess);

            if (word.contains(String.valueOf(guess))) {
                System.out.println("Boa! A letra está na palavra.");
                if (isWordComplete()) {
                    System.out.println("\n🎉 Você venceu! A palavra era: " + word);
                    return;
                }
            } else {
                System.out.println("Errado! A letra não está na palavra.");
                attempts--;
            }
        }

        System.out.println("\n💀 Você perdeu! A palavra era: " + word);
    }

    private String getMaskedWord() {
        StringBuilder masked = new StringBuilder();
        for (char c : word.toCharArray()) {
            masked.append(usedLetters.contains(c) ? c : "_");
            masked.append(" ");
        }
        return masked.toString();
    }

    private boolean isWordComplete() {
        for (char c : word.toCharArray()) {
            if (!usedLetters.contains(c)) return false;
        }
        return true;
    }
}
