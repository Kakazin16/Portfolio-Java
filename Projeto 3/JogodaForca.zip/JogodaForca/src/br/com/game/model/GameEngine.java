package br.com.game.model;

public class GameEngine {

    public void run(Game game) {
        game.start();
    }
}
