package br.com.game.main;
import br.com.game.model.GameEngine;
import br.com.game.model.HangmanGame;

public class Main {

	public static void main(String[] args) {
        GameEngine engine = new GameEngine();
        engine.run(new HangmanGame());
	}

}
