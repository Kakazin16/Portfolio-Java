package br.com.fiap.calculargeometria.model;

public class Retângulo extends Calcular{
	
	private double base;
	private double altura;
	
	

	public Retângulo(double base, double altura) {
		super();
		this.base = base;
		this.altura = altura;
	}

	@Override
	public void calcularArea() {
		area = base * altura;
	}

	@Override
	public void calcularPerimetro() {
		perimetro = 2 * (base + altura);
	}

}
