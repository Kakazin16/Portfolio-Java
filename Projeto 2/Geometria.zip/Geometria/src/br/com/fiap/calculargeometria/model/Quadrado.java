package br.com.fiap.calculargeometria.model;

public class Quadrado extends Calcular {

    private double lado;

    public Quadrado(double lado) {
        this.lado = lado;
    }

    @Override
    public void calcularArea() {
        area = Math.pow(lado, 2);
    }

    @Override
    public void calcularPerimetro() {
        perimetro = 4 * lado;
    }
}
