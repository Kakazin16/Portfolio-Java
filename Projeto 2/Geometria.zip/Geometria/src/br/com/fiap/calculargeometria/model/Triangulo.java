package br.com.fiap.calculargeometria.model;

public class Triangulo extends Calcular {

    private double base;
    private double altura;
    private double ladoA, ladoB, ladoC;

    public Triangulo(double base, double altura, double ladoA, double ladoB, double ladoC) {
        this.base = base;
        this.altura = altura;
        this.ladoA = ladoA;
        this.ladoB = ladoB;
        this.ladoC = ladoC;
    }

    @Override
    public void calcularArea() {
        area = (base * altura) / 2;
    }

    @Override
    public void calcularPerimetro() {
        perimetro = ladoA + ladoB + ladoC;
    }
}
