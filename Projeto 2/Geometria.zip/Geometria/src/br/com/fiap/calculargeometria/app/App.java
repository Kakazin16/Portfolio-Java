package br.com.fiap.calculargeometria.app;

import java.util.Scanner;

import br.com.fiap.calculargeometria.model.*;

public class App {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int opcao;
		
		do {
            System.out.println("\n=== Calculadora Geométrica ===");
            System.out.println("1 - Círculo");
            System.out.println("2 - Retângulo");
            System.out.println("3 - Quadrado");
            System.out.println("4 - Triângulo");
            System.out.println("5 - Sair");
            System.out.print("Escolha: ");
            opcao = sc.nextInt();

            switch (opcao) {
                case 1 -> {
                    System.out.print("Raio: ");
                    double r = sc.nextDouble();
                    Circulo c = new Circulo(r);
                    c.calcularArea();
            		System.out.printf("A área do círculo é: %.2f%n", c.getArea());
                    c.calcularPerimetro();
            		System.out.printf("O perimetro do circulo é: %.2f%n", c.getPerimetro());
                }
                case 2 -> {
                    System.out.print("Base: ");
                    double b = sc.nextDouble();
                    System.out.print("Altura: ");
                    double h = sc.nextDouble();
                    Retângulo r2 = new Retângulo(b, h);
                    r2.calcularArea();
                    System.out.printf("A area do retângulo é: %.2f%n", r2.getArea());
                    r2.calcularPerimetro();
                    System.out.printf("O perimetro do retângulo é %.2f%n", r2.getPerimetro());
                }
                case 3 -> {
                    System.out.print("Lado: ");
                    double lado = sc.nextDouble();
                    Quadrado q = new Quadrado(lado);
                    q.calcularArea();
                    q.calcularPerimetro();
                    System.out.println("Área: " + q.getArea());
                    System.out.println("Perímetro: " + q.getPerimetro());
                }
                case 4 -> {
                    System.out.print("Base do triângulo: ");
                    double base = sc.nextDouble();
                    System.out.print("Altura do triângulo: ");
                    double altura = sc.nextDouble();

                    System.out.print("Lado A: ");
                    double a = sc.nextDouble();
                    System.out.print("Lado B: ");
                    double b2 = sc.nextDouble();
                    System.out.print("Lado C: ");
                    double c2 = sc.nextDouble();

                    Triangulo t = new Triangulo(base, altura, a, b2, c2);
                    t.calcularArea();
                    t.calcularPerimetro();

                    System.out.printf("Área: %.2f%n", t.getArea());
                    System.out.printf("Perímetro: %.2f%n", t.getPerimetro());
                }
                
                case 5 -> {
                	System.out.println("Encerrando...");
                }
                default -> {
                	System.out.println("Opção inválida!");
                }
            }

        } while (opcao != 5);

        sc.close();

	}

}
