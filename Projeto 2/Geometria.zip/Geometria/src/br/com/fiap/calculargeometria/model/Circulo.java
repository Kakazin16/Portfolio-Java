package br.com.fiap.calculargeometria.model;

public class Circulo extends Calcular {
	
	private double r;
	private double pi = Math.PI;
	

	public Circulo(double r) {
		super();
		this.r = r;
	}

	@Override
	public void calcularArea() {
		area = pi * Math.pow(r,  2);
	}

	@Override
	public void calcularPerimetro() {
		perimetro = 2 * pi * r;
	}

}
